package com.example.design.factory;

public interface OS
{
    public void spec();
}
