package com.example.design.factory;

public class AndroidOS implements OS {
    @Override
    public void spec() {
        System.out.println("most used OS");
    }
}
