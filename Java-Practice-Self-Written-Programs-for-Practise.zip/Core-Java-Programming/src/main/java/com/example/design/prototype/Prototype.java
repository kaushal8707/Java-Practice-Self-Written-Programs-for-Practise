package com.example.design.prototype;

public interface Prototype
{
    Prototype getClone();
}
