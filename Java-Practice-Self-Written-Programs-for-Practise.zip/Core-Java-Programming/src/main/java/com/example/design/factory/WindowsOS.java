package com.example.design.factory;

public class WindowsOS implements OS {
    @Override
    public void spec() {
        System.out.println("It is about to die");
    }
}
