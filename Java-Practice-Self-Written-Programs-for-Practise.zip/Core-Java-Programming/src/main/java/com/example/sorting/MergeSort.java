package com.example.sorting;

public class MergeSort {
}
