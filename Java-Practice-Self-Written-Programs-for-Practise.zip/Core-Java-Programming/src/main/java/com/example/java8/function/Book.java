package com.example.java8.function;

public class Book
{
    private String bookName = "Mahabharat";
    public String getBookName(){
        return bookName;
    }
}
