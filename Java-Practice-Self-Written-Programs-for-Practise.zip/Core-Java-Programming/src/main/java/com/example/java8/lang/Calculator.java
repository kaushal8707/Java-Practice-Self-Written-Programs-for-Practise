package com.example.java8.lang;

public interface Calculator
{
    public int add(int a,int b);
}
