package com.example.logic;

public class StatisticsUtility
{
    public static int addInteger(int num1,int num2)
    {
        return (num1+num2);
    }
}
