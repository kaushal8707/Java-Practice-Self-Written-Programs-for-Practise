package com.example.logic;

public class Employees
{
    public int id;
    public String name;
    public int sal;
    public Employees(int id,String name,int sal  ){
        this.id = id;
        this.name = name;
        this.sal = sal;
    }
}
